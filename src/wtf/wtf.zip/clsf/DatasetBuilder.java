package wtf.clsf;

public class DatasetBuilder {
    public Dataset build() {
        return null;// new Dataset(numObjects, numRatAttr, numCatAttr, numClasses);
    }
}
